/*
 * LodamModbusProject.cpp
 *
 *  Created on: Feb 14, 2015
 *      Author: imtiazahmed
 */

#include <iostream>
#include "ModbusController.h"
#include "ServerController.h"
#include "Utility.h"
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>

#include<sys/socket.h>    //socket
#include<arpa/inet.h> //inet_addr
#include <sys/signal.h>



#include <errno.h>
#include <signal.h>
#include <sys/types.h>

#include <fcntl.h>
#include <sys/stat.h>


using namespace std;

pid_t cpid; 

int pro_fd, wd_fd;
char pipe_buf[1024];

int wd_sock;

struct sockaddr_in server;

bool mod_bus_ready=false;

//int device_ids[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
int total_devices_count = 8;

//int register_ids[] = { 203, 221, 400, 401, 402, 403, 404, 405, 406, 407, 408,
//	409, 1000, 1001, 1002, 1003, 1004 };


//int total_register_count = 17;
string serverAddress = "";
int serverPort = 0;
int modbus_interval = 0;
bool show_output = true;
unsigned long long ctr = 0;

Utility utility;

unsigned char* mac_address;




static struct s_timeout_info timeout_info[10];

static struct s_dev_config dev_config[8];
unsigned char m_reply_message[MAX_MESSAGE_LENGTH];
unsigned char packet[2100];
int m_reply_length;

ModbusController modbusController;
ServerController serverController;

#define MAX_BUF 1024




/**
 * Loop and read status from devices using Modbus protocol
 * and send data to server
 */
int work() {


	try {

		//		ModbusController modbusController;
		//		ServerController serverController;

		// 5 for command number and length + (  17 registers * 2 (reg number ) * 2 (reg value))
		unsigned char devices_data[8][5 + 68];

		for (int i = 0; i < total_devices_count; i++) {
			utility.clearBytes(devices_data[i], 0, 5 + 68);
		}

		//unsigned char m_communication_message[256];

		int total_bytes = 0;

		int change_counter;

		int timer = 0;

		//serverController.setIDForCommunication(mac_address);
		if (!modbusController.establishConnection()) {
			printf(" Can not connect to USB \n");
			//			return 0;
		}

		bool connected = false;
		int read_length = 0;
		unsigned char* data_from_server;
		unsigned char* data_from_modbus;
		int reply_length;

		do
		{

			show_output = false;

			/*if (++ctr % 500 == 0) {

				show_output = true;
				cout << "\nREAD COUNTER  = " << ctr;

				if(ctr > 100000) {ctr = 0;}

			}*/
			connected=serverController.isConnected();

			//if not connected, try to connect to server
			if (connected!=true) {
				connected = serverController.connectWithServer(serverAddress,serverPort,wd_sock);


				if (connected) {
					printf("yas %d: connected=%d func=%s, file=%s\n",__LINE__,connected,__FUNCTION__,__FILE__);
					serverController.setIDForCommunication(mac_address);
					//send welcome message, the server will either return success
					//or will return with the values to be written to the registers
					serverController.sendWelcomeMessage(timeout_info);
					mod_bus_ready=false;
#if 0
					//Check the last reply returned by server after welcome message
					data_from_server = serverController.getLastReplyFromServer(
							read_length);

					//now give the data to modbus controller, it will parse and write on registers
					//of given device, if required.
					//if returned values is true, report it to server.
					reply_length = modbusController.parseCommands(
							data_from_server, read_length,mac_address,timeout_info,dev_config);

					data_from_modbus= modbusController.getLastReply(reply_length);

						if (reply_length > 0) {

							//utility.printBytes(data_from_modbus,0,reply_length);
							serverController.sendCommandReply(data_from_modbus,reply_length);
						}
#endif						

				} else {
					if (mod_bus_ready==false || total_devices_count<1){
					sleep(1);
					continue;
					}
					//connection with server failed, exit the program
					//watch dog will start it again
					cout << "CONNECTION WITH SERVER FAILED..." << endl;
				//	return 0;
#if 1				
				for (int device_ctr = 0; device_ctr < total_devices_count;
						device_ctr++) {

					//if device id on given index is 0, move to next one
					if (/*device_ids[device_ctr]*/dev_config[device_ctr].device_id == 0) {
						continue;
					}

					timer = 0;

					//do{

						change_counter = 0;

						if (show_output) {
							cout << endl
								<< "==============================================";
							cout << endl << "Device_id = " << /*device_ids[device_ctr]*/dev_config[device_ctr].device_id
								<< endl;
							cout << endl;
						}

/*						total_bytes = modbusController.readRegistersOfADevice(
								device_ids[device_ctr], register_ids,
								devices_data[device_ctr], total_register_count,
								change_counter, show_output);*/
						total_bytes = modbusController.readRegistersOfADevice(
                                                                dev_config[device_ctr].device_id, dev_config[device_ctr].register_ids,
                                                                devices_data[device_ctr], dev_config[device_ctr].total_register_count,
                                                                change_counter, show_output);

						/*if (show_output) {
							cout << endl << "-------------------------------------"
								<< endl;
							cout << endl << "Change_index = " << change_counter
								<< " Read Length = " << total_bytes << endl;
						}

						//value of none of the sensor changed, must be due to some error
						if (change_counter == 0) {
							timer++;
							total_bytes=0;
						}

						//if no values were found changed for 5 times, try to reconnect the port
						if (timer >= 5) {

							//cout << "Exiting inner loop.. " << endl;
							timer = 0;
							break;
							//modbusController.releaseConnection();
							//sleep(3);
							//modbusController.establishConnection();

							//read data again
							//						//return 1;
						}
					}while(change_counter == 0);*/
					if(total_bytes>0)
						serverController.logDevicesStatus(devices_data[device_ctr], total_bytes);

					
					}
#endif					
				}
			}

			//if connected, loop through the devices and send the data to server
			if (connected) {
				printf("yas %d: mod_bus_ready=%d func=%s, file=%s\n",__LINE__,mod_bus_ready,__FUNCTION__,__FILE__);
				//timer++;

				//check if value of any register is changed - if so send the values of all registers for that device only
				if (mod_bus_ready==false || total_devices_count<1){
					sleep(1);
					continue;
				}

				
				for (int device_ctr = 0; device_ctr < total_devices_count;
						device_ctr++) {

					//if device id on given index is 0, move to next one
					if (/*device_ids[device_ctr]*/dev_config[device_ctr].device_id == 0) {
						printf("yas %d: dev_config[%d].device_id=%d total_devices_count=%d func=%s, file=%s\n",__LINE__,device_ctr,dev_config[device_ctr].device_id,total_devices_count,__FUNCTION__,__FILE__);
						continue;
					}
					

					timer = 0;

					//do{

						printf("yas %d: Device_id =%d  total_devices_count=%d func=%s, file=%s\n",__LINE__,dev_config[device_ctr].device_id,total_devices_count,__FUNCTION__,__FILE__);
						change_counter = 0;

						if (show_output) {
							cout << endl
								<< "==============================================";
							cout << endl << "Device_id = " << /*device_ids[device_ctr]*/dev_config[device_ctr].device_id
								<< endl;
							cout << endl;
						}

/*						total_bytes = modbusController.readRegistersOfADevice(
								device_ids[device_ctr], register_ids,
								devices_data[device_ctr], total_register_count,
								change_counter, show_output);*/
						total_bytes = modbusController.readRegistersOfADevice(
                                                                dev_config[device_ctr].device_id, dev_config[device_ctr].register_ids,
                                                                devices_data[device_ctr], dev_config[device_ctr].total_register_count,
                                                                change_counter, show_output);

						/*if (show_output) {
							cout << endl << "-------------------------------------"
								<< endl;
							cout << endl << "Change_index = " << change_counter
								<< " Read Length = " << total_bytes << endl;
						}

						//value of none of the sensor changed, must be due to some error
						if (change_counter == 0) {
							timer++;
							total_bytes=0;
						}

						//if no values were found changed for 5 times, try to reconnect the port
						if (timer >= 5) {

							//cout << "Exiting inner loop.. " << endl;
							timer = 0;
							break;
							//modbusController.releaseConnection();
							//sleep(3);
							//modbusController.establishConnection();

							//read data again
							//						//return 1;
						}
					}while(change_counter == 0);*/

					if (/*total_bytes > 0 && change_counter > 0 yas error*/1) {
						if (show_output) {
							cout << "\nSending data to server ";
						}

						
						//more than one register changed, send the data to server
						bool status = serverController.sendDevicesStatus(devices_data[device_ctr], total_bytes);
#if 0
						data_from_server = serverController.getLastReplyFromServer(read_length);

						//now give the data to modbus controller, it will parse and write on registers
						//of given device, if required.
						//if returned values is true, report it to server.
						reply_length = modbusController.parseCommands(data_from_server, read_length,mac_address,timeout_info,dev_config);

						data_from_modbus= modbusController.getLastReply(reply_length);

						if (reply_length > 0) {

							//utility.printBytes(data_from_modbus,0,reply_length);
							serverController.sendCommandReply(data_from_modbus,reply_length);
						}

						if (show_output) {
							cout << endl << "Done with status " << status
								<< endl;
						}

						//if there was a problem sending data to server try to reconnect
						if (!status) {
							//							serverController.disconnect();
							//							connected = false;
							//							break;
						}
#endif						
					}

					if (show_output) {
						cout << "=============================================="
							<< endl;
					}

				}

			}
			

			//sleep(2);
			sleep(modbus_interval);
			write(wd_sock, "ping", 4);
		}

		while (true);
		modbusController.releaseConnection();

	} catch (exception &e) {
		cout << "Standard exception: " << e.what() << endl;
	} catch (...) {

	}

	return 0;

}

void create_reply(unsigned char* mac,int commandid, bool success,int cmd_ver){
	memcpy(m_reply_message+m_reply_length,mac,6);
	m_reply_message[m_reply_length+6]=commandid;
	if(success)
		m_reply_message[m_reply_length+7]=1;
	else
		m_reply_message[m_reply_length+7]=0;
	m_reply_message[m_reply_length+8]=cmd_ver;
	m_reply_message[m_reply_length+9]=0;
	m_reply_length=m_reply_length+10;
}

void create_reply_and_send(unsigned char* mac,int commandid, bool success,int cmd_ver){
	char reply_packet[MAX_MESSAGE_LENGTH];
	//int m_reply_length
	memcpy(reply_packet,mac,6);
	reply_packet[6]=commandid;
	/*if(success)
		reply_packet[7]=1;
	else
		reply_packet[7]=0;*/
	reply_packet[7]=success;
	reply_packet[8]=cmd_ver;
	reply_packet[9]=0;
	serverController.socketWrite(reply_packet,10);
}


int create_remote_file_size_reply_and_send(uint8_t* buffer, int len,unsigned char* mac,int commandid, bool success){
	uint8_t filename[UPDATE_APPLICATION_DATASIZE];
        char abs_path[UPDATE_APPLICATION_DATASIZE];
        FILE * pFileTXT;
        int buff_length;

        if (buffer[7]!=2){
                printf("Not a request!!!\n");
                return 0;
        }
        /*if (len!=96){
          printf("Wrong Size!!!\n");
          return 0;
          }*/

	//      unsigned char reply_packet[MAX_MESSAGE_LENGTH];
        memset(m_reply_message,0,MAX_MESSAGE_LENGTH);
        m_reply_length=0;
        //create_reply(mac,commandid,success,1);

        memcpy(m_reply_message+m_reply_length,mac,6);
        m_reply_message[m_reply_length+6]=commandid;
	m_reply_message[m_reply_length+8]=1; // for file size reply
	m_reply_message[m_reply_length+9]=1; // reply packet


	memset(filename,0,UPDATE_APPLICATION_DATASIZE);
	int filenamelen = utility.getIntFromArray(buffer, 10);

	memcpy(filename,buffer+12,filenamelen);
	sprintf(abs_path,"/home/Moxa/remote_cache/%s",(char *)filename);
	if(buffer[9]==1){
		m_reply_message[m_reply_length+10]=1;
		struct stat st = {0};

		printf("yas %d: file_name=%s func=%s, file=%s\n",__LINE__,abs_path,__FUNCTION__,__FILE__);
		if (stat((char *)abs_path, &st) == -1) 
			m_reply_message[m_reply_length+7]=0;//return 0

		else
			m_reply_message[m_reply_length+7]=1;//return 1;

	}
	else{
		m_reply_message[m_reply_length+10]=0;
		unsigned long int byte_received=utility.get_file_size(abs_path);
		printf("yas %d: file_name=%s byte_received=%d func=%s, file=%s\n",__LINE__,abs_path,byte_received,__FUNCTION__,__FILE__);
		if(byte_received>0)
			m_reply_message[m_reply_length+7]=1;
		else
			m_reply_message[m_reply_length+7]=0;
		utility.loadLongInArray(byte_received, m_reply_message, 11);
		/*long crc=modbusController.crc16(m_reply_message, 18);
		  utility.loadIntInArray(crc,m_reply_message, 18);*/
	}





	m_reply_length=m_reply_length+20;
	serverController.socketWrite(m_reply_message,m_reply_length);
	
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
        modbusController.printBytes(m_reply_message,m_reply_length);
        printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);

	

}
void send_install_log_reply_and_send(unsigned char* mac,int commandid, bool success){

	memset(m_reply_message,0,MAX_MESSAGE_LENGTH);
	m_reply_length=0;
	char buffer[500];
	long length;
	FILE * f = fopen ("/home/Moxa/install_log", "rb");

	if (f)
	{
		fseek (f, 0, SEEK_END);
		length = ftell (f);
		fseek (f, 0, SEEK_SET);
		fread (buffer, 1, length, f);
		fclose (f);
	}

	if (strlen(buffer)>0)
	{
		// start to process your data / extract strings here...
		create_reply(mac,commandid,1,3);
		m_reply_message[9]=length;
		memcpy(m_reply_message+10,buffer,length);
		m_reply_length=m_reply_length+length;
	}
	else{
		create_reply(mac,commandid,0,3);
	}
	serverController.socketWrite(m_reply_message,m_reply_length);

}
void start_script_and_send (unsigned char* mac,int commandid, bool success){
		
//		utility.runBashCom("echo \"start installing...\" > /home/Moxa/installing");
		//utility.runBashCom("rm -rf /home/Moxa/remote_cache");
		//utility.runBashCom("mkdir /home/Moxa/remote_cache");
		utility.runBashCom("chmod 755 /home/Moxa/* 2> /home/Moxa/install_log");
		//utility.runBashCom("mv /home/Moxa/recv_file /home/Moxa/remote_cache/remote_update.tar.gz 2>> /home/Moxa/install_log");
		//utility.runBashCom("tar xvf /home/Moxa/remote_cache/remote_update.tar.gz -C /home/Moxa/remote_cache/ 2>> /home/Moxa/install_log");
		utility.runBashCom("sh /home/Moxa/remote_cache/install.sh 2>> /home/Moxa/install_log");
//		utility.runBashCom("rm /home/Moxa/installing");
//		utility.runBashCom("");
	
		create_reply_and_send(mac,commandid,1,2);
}

int remote_update(uint8_t* buffer, int len,struct s_timeout_info * timeout_info) {

	uint8_t data_buf[UPDATE_APPLICATION_DATASIZE];
	uint8_t filename[UPDATE_APPLICATION_DATASIZE];
	char abs_path[UPDATE_APPLICATION_DATASIZE];
	FILE * pFileTXT;
	int buff_length;

	if (buffer[7]!=2){
		printf("Not a request!!!\n");
		return 0;
	}
	/*if (len!=96){
	  printf("Wrong Size!!!\n");
	  return 0;
	  }*/

	//	int packet_num = utility.getIntFromByte(buffer, 8);
	long crc=modbusController.crc16(buffer, len-2);
	long packet_crc = utility.getIntFromByte(buffer, len-2);
        if(crc!=packet_crc){
                printf("yas %d: Wrong crc patcket_crc=%ld crc=%ld  len=%d func=%s, file=%s\n",__LINE__, packet_crc,crc,len,__FUNCTION__,__FILE__);
                return 0;
        }
	memset(filename,0,UPDATE_APPLICATION_DATASIZE);
        int filenamelen = utility.getIntFromArray(buffer, 10);
	//filenamelen=utility.getLongIntFromByte(buffer,10);
	memcpy(filename,buffer+12,filenamelen);
	long int packet_num=  utility.getLongIntFromByte(buffer,filenamelen+12);
        long int total_packets=  utility.getLongIntFromByte(buffer,filenamelen+20);
	sprintf(abs_path,"/home/Moxa/remote_cache/%s",(char *)filename);
	if(buffer[9]==1){
		printf("yas %d: creating  file_name=%s func=%s, file=%s\n",__LINE__,abs_path,__FUNCTION__,__FILE__);
		mkdir((char *)abs_path, 0755);
		return 1;
		
	}
	buff_length =utility.getIntFromArray(buffer, filenamelen+28);
//	buff_length=len-(UPDATA_APPLICATION_FRAMESIZE+CRCSIZE);

	printf("yas %d: pcket_num=%d buf_len=%d func=%s, file=%s\n",__LINE__,packet_num,buff_length,__FUNCTION__,__FILE__);
	memcpy(data_buf,buffer+filenamelen+30,buff_length);
	if(packet_num<1){
		pFileTXT = fopen (abs_path,"w");
		(timeout_info[0].timeout_status)=true;
	}
	else
		pFileTXT = fopen (abs_path,"a");// use "a" for append, "w" to overwrite, previous content will be deleted


	int fret=fwrite(data_buf, sizeof(data_buf[0]), buff_length , pFileTXT);
	fclose (pFileTXT); // must close after opening
	if(packet_num>=(total_packets-1)){

		(timeout_info[0].timeout_status)=false;


/*		system("mkdir remote_cache");

		sleep(1);
		system("chmod 755 *");

		sleep(1);
		system("cp recv_file remote_cache/remote_update.tar.gz");
		sleep(1);

		system("tar xvf remote_cache/remote_update.tar.gz -C remote_cache/");
		sleep(3);

		system("sh remote_cache/install.sh");
		sleep(3);*/

	}
	if(fret<1){
		printf("yas %d: pcket_num=%d buf_len=%d Write Error=%d func=%s, file=%s\n",__LINE__,packet_num,buff_length,fret,__FUNCTION__,__FILE__);
		return -1;
	}
	else
		return 1;

}

int mk_cache_slice(int size){

	FILE * cashe;
	FILE * cashe_temp;
	FILE * cashe_lines;
	int count_bytes=0;
	char cached[]={"/home/Moxa/data_cashe"};
	char cached_temp[]={"/home/Moxa/data_cashe_temp"};
	char cached_lines[]={"/home/Moxa/cashe_lines"};
	int cache_lines=0;
	int count_lines=0;
	bool cache_end=false;
	char ch;
	time_t now = time(0);
	cashe = fopen (cached,"rb");
	if (cashe == NULL)
	{	
		return 1;
	}

	while(count_bytes<size)
	{
		if(feof(cashe)){
			cache_end=true;
			break;
			}
		ch = fgetc(cashe);
		if(ch == ';')
		{
			cache_lines++;
		}
		count_bytes++;
	}
	rewind(cashe);
	
	cashe_temp = fopen (cached_temp,"wb");
		if (cashe_temp == NULL)
		{
			printf("Error opening file! data_cashe_temp\n");
			fclose(cashe);
			return 1;

		}
		cashe_lines = fopen (cached_lines,"wb");
		if (cashe_lines == NULL)
		{
			fclose(cashe);
			fclose(cashe_temp);
			printf("Error opening file! cashe_lines\n");
			return 1;
		}
	while(!feof(cashe))
	{
		ch = fgetc(cashe);
		

		if(count_lines<cache_lines)
			fputc(ch, cashe_lines);
		else
			fputc(ch, cashe_temp);
			
		if(ch == ';')
		{
				count_lines++;
		}
	}
		fclose(cashe_temp);
		fclose(cashe);	
		fclose(cashe_lines);	
	
		if(remove(cached) == 0)
			printf("File %s  deleted.\n", cached);
		else
			fprintf(stderr, "Error deleting the file %s.\n", cached);
		if(!cache_end){
		if(rename(cached_temp, cached) == 0)
		{
			printf("%s has been rename %s.\n", cached_temp, cached);
		}
		else
		{
			fprintf(stderr, "Error renaming %s.\n", cached_temp);
		}
		}
		else{
			if(remove(cached_temp) == 0)
			printf("File %s  deleted.\n", cached_temp);
		else
			fprintf(stderr, "Error deleting the file %s.\n", cached_temp);
		}
		


	return 0;
	
}


int getGatewayCashe(unsigned char* mac){
	int cache_succ=0;
	FILE * cashe_lines;
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
	cashe_lines = fopen( "/home/Moxa/cashe_lines", "rb" ) ;
	if(  cashe_lines == NULL ) // checks to see if file dogs exists
    { 
        cout << "File not found\n";
        cache_succ=mk_cache_slice(500);
			if(cache_succ==0){
				cashe_lines = fopen( "/home/Moxa/cashe_lines", "rb" ) ;
				if(  cashe_lines == NULL ) // checks to see if file dogs exists
					return 0;
				}
			else{
				return 0;
			}
         
    }
	

		
	memset(m_reply_message,0,MAX_MESSAGE_LENGTH);
	m_reply_length=0;
	unsigned char buffer[500];
	long length;
	//FILE * f = fopen ("cashe_lines", "rb");

	if (cashe_lines)
	{
		fseek (cashe_lines, 0, SEEK_END);
		length = ftell (cashe_lines);
		fseek (cashe_lines, 0, SEEK_SET);
		fread (buffer, 1, length, cashe_lines);
		fclose (cashe_lines);
	}

	if (strlen((char *)buffer)>0)
	{

		// start to process your data / extract strings here...
		memcpy(m_reply_message+m_reply_length,mac,6);
		m_reply_message[m_reply_length+6]=99;
		m_reply_message[m_reply_length+7]=2;
		m_reply_message[m_reply_length+8]=0;
		m_reply_message[9]=length;
		m_reply_length=10;
		memcpy(m_reply_message+10,buffer,length);
		m_reply_length=m_reply_length+length+2;
		long crc=modbusController.crc16(buffer, length);
		utility.loadIntInArray(crc,m_reply_message, m_reply_length);
		m_reply_length=m_reply_length+2;
		serverController.socketWrite(m_reply_message,m_reply_length);
		/*printf("yas %d: length=%d crc=%ld func=%s, file=%s\n",__LINE__,m_reply_length,crc,__FUNCTION__,__FILE__);
	modbusController.printBytes(m_reply_message,m_reply_length);
	printf("yas %d: length=%d func=%s, file=%s\n",__LINE__,m_reply_length,__FUNCTION__,__FILE__);*/
	}

}
int removeFile(char * name){
	if(remove(name) == 0)
			printf("File %s  deleted.\n", name);
		else
			fprintf(stderr, "Error deleting the file %s.\n", name);
	}
int setGatewayConf(uint8_t* pack, int len,struct s_dev_config* dev_config){
	long packet_crc = utility.getIntFromByte(pack, len-2);
                        long crc=modbusController.crc16(pack, len-2);
                        if(crc==packet_crc){
                                int index=9;
                                int total_dev=pack[index++];
                                total_devices_count=total_dev;
				printf("yas %d: total_dev=%d pack[index++]=%d func=%s, file=%s\n",__LINE__,total_dev,pack[index],__FUNCTION__,__FILE__);
                                for (int d=0; d<total_dev; d++){
                                        dev_config[d].device_id=utility.getIntFromArray(pack, index);
                                        index=index+2;
					printf("yas %d: dev_config[%d].device_id=%d func=%s, file=%s\n",__LINE__,d,dev_config[d].device_id,__FUNCTION__,__FILE__);
                                        dev_config[d].total_register_count=pack[index++];
                                        for (int r =0; r < dev_config[d].total_register_count ; r++){
                                                dev_config[d].register_ids[r]=utility.getIntFromArray(pack, index);
						printf("yas %d: dev_config[%d].register_ids[%d]=%d func=%s, file=%s\n",__LINE__,d,r,dev_config[d].register_ids[r],__FUNCTION__,__FILE__);
                                                index=index+2;
                                        }
                                }
                                
				return 1;
                        }
                        else
                                printf("yas %d: Connect Message Status incorrent crc=%ld packet_crc=%ld func=%s, file=%s\n",__LINE__,crc,packet_crc,__FUNCTION__,__FILE__);
			return 0;
			
}
int parseCommands(unsigned char* buff, int length,unsigned char* mac_address,struct s_timeout_info* timeout_info,struct s_dev_config* dev_config){

	//Sample data coming in
	//
	//00 :0C :29 :AF :71 :3B :31 :02 :00 :07 :01 :1F :01 :03 :E9 :00 :01
	//
	//0-5    MAC ID
	//6th    Command number, must be 49

	int device_id = 0;
	int total_registers_count = 0;
	//int total_devices_count = 0;
	int data_pointer = 6;
	int register_address = 0;
	int register_value = 0;
	int reply_state;
	int num_reply;

	uint16_t result[1];
	result[0] = 0;


//	unsigned char data[2100];
	int packet_length=0;
	int pakcet_index=0;

/*	printf("\n\n\n\nyas %d: length=%d func=%s, file=%s\n",__LINE__,length,__FUNCTION__,__FILE__);
	modbusController.printBytes(buff,length);
	printf("yas %d: length=%d func=%s, file=%s\n",__LINE__,length,__FUNCTION__,__FILE__);*/
//	 printBytes(mac_address,6);

	memset(m_reply_message,0,MAX_MESSAGE_LENGTH);
	m_reply_length=0;
	packet_length=utility.findpattren(buff, mac_address, length,6,pakcet_index);
	if(packet_length<0)
		return 0;
	do{
		data_pointer = 6;
		memset(packet,0,1000);
		packet_length=utility.findpattren(buff, mac_address, length,6,pakcet_index+6);
		if(packet_length<0)
			packet_length=length-pakcet_index;
		else{
			packet_length=packet_length-pakcet_index;

		}

		memcpy(packet,buff+pakcet_index,packet_length);

/*		printf("yas %d: packet index=%d packet end=%d total_length=%d pakcet_len=%d func=%s, file=%s\n",__LINE__,pakcet_index,pakcet_index+packet_length,length,packet_length,__FUNCTION__,__FILE__);
		printBytes(packet,packet_length);
		printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);*/

		int command=packet[data_pointer++];
		int status=packet[data_pointer++];
		switch(command){
			case 40:
				timeout_info[1].timeout_cycle=true;
				printf("yas %d: Connect Message Status=%d func=%s, file=%s\n",__LINE__,status,__FUNCTION__,__FILE__);
				if(status==2){
					reply_state=setGatewayConf(packet, packet_length,dev_config);
					
					if(reply_state){
						timeout_info[1].timeout_status=false;
						timeout_info[1].timeout_cycle=false;
						mod_bus_ready=true;
						
						getGatewayCashe(mac_address);
					}
					else
						create_reply_and_send(mac_address,command,reply_state,0);
				}
				break;
			case 99:
				printf("yas %d: Cache Message Status=%d func=%s, file=%s\n",__LINE__,status,__FUNCTION__,__FILE__);
				if(status)
					removeFile("/home/Moxa/cashe_lines");
				getGatewayCashe(mac_address);
				//create_reply_and_send(mac_address,command,reply_state,1);
				break;
			case 100:
				if(packet[8]==0){
				printf("yas %d: Update Application Status=%d func=%s, file=%s\n",__LINE__,status,__FUNCTION__,__FILE__);
				reply_state=remote_update(packet, packet_length,timeout_info);
				create_reply_and_send(mac_address,command,reply_state,0);

				timeout_info[0].timeout_cycle=true;
				timeout_info[0].timeout_len=m_reply_length;

				memcpy(timeout_info[0].timeout_packet,m_reply_message,m_reply_length);
				}

				if(packet[8]==1){	// Check File Size
					printf("yas %d: Update Application Status=%d func=%s, file=%s\n",__LINE__,status,__FUNCTION__,__FILE__);
					create_remote_file_size_reply_and_send(packet,packet_length,mac_address,command,reply_state);
/*					utility.runBashCom("rm -rf /home/Moxa/remote_cache");
			                utility.runBashCom("mkdir /home/Moxa/remote_cache");
			                utility.runBashCom("chmod 755 /home/Moxa/* 2> /home/Moxa/install_log");
			                utility.runBashCom("mv /home/Moxa/recv_file /home/Moxa/remote_cache/remote_update.tar.gz 2>> /home/Moxa/install_log");
			                utility.runBashCom("tar xvf /home/Moxa/remote_cache/remote_update.tar.gz -C /home/Moxa/remote_cache/ 2>> /home/Moxa/install_log");*/
				}
				if(packet[8]==2){ // install unzip and isntall remote updates
//                                        create_remote_file_size_reply(mac_address,command,reply_state);
					printf("yas %d: Update Application Status=%d func=%s, file=%s\n",__LINE__,status,__FUNCTION__,__FILE__);
					start_script_and_send(mac_address,command,reply_state);
                                }
				if(packet[8]==3){ // Request Firmware Version Number
					printf("yas %d: Update Application Status=%d func=%s, file=%s\n",__LINE__,status,__FUNCTION__,__FILE__);
                                        send_install_log_reply_and_send(mac_address,command,reply_state);
                                }
				if(packet[8]==4){ // Request Firmware Version Number
                                        printf("yas %d: Update Application Status=%d func=%s, file=%s\n",__LINE__,status,__FUNCTION__,__FILE__);
					sleep(3);
                                        exit(0); 
                                }
				break;

			default:
				break;


		}


		int remaining_packet_length = utility.getIntFromByte(packet, data_pointer);



		//move the pointer forward as last remaining_packet_length is of two bytes.
		if(command==49){
			/*if (remaining_packet_length >6) {
				data_pointer += 2;

				//check how many devices we need to update.
				total_devices_count = packet[data_pointer++];

				//loop through the devices
				for (int i = 0; i < total_devices_count; i++) {
					device_id = packet[data_pointer++];
					total_registers_count = packet[data_pointer++];

					cout << endl << "Device ID = " << device_id << endl;

					//check the registers that are needed to be updated.
					//loop through them and send the write register command one by one
					//it is that easy.
					for (int ctr = 0; ctr < total_registers_count; ctr++) {
						register_address = utility.getIntFromByte(packet, data_pointer);
						data_pointer += 2;

						register_value = utility.getIntFromByte(packet, data_pointer);
						data_pointer += 2;

						cout << endl << "-------------------------------------" << endl;
						printf("r= %d   v= %d\n", register_address, register_value);
						cout << endl << "-------------------------------------";

						sendWriteCommand(device_id, register_address, register_value,
								result);
					}

					cout << endl;
				}
			}*/
			modbusController.parseCommand(packet,packet_length);
		}

		pakcet_index=pakcet_index+packet_length;
	}while(pakcet_index<length);
	return 0;
}

void *Recevier(void*)
{

	try {
		int buffer_length = 2000;
		bool connected = false;
		int read_length = 0;
		unsigned char* data_from_server;
		int reply_length;

		//buffer to read the bytes in
		unsigned char buffer[buffer_length];
		while(1){
			connected=serverController.isConnected();
/*			if(connected==true)
				printf("yas%d: Server Connected! func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
			else
				printf("yas%d: Server not Connected! func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);*/

			//if not connected, try to connect to server
			if (connected) {
				//send welcome message, the server will either return success
				//or will return with the values to be written to the registers
				reply_length=serverController.socketRead(buffer,buffer_length);
				if (reply_length>0){
					
					reply_length = parseCommands(buffer, reply_length,mac_address,timeout_info,dev_config);

/*					if (reply_length > 0) {
						//if there is a data to be written, write it to server
						//the modbusController.parseCommand would have updated the array (as they are passed as ref)
						//so just send the number of bytes, from start, to write to server
						serverCsendCommandReply(reply_length);


						//sendPacket(dev_mac,client_message,read_size);

					}*/

				}
			}

			// sleep(1);
			//usleep(1000);
			//usleep(35 * 500);
		}
	} catch (exception &e) {
		cout << "Standard exception: " << e.what() << endl;
	} catch (...) {

	}


	//	pthread_exit(NULL);
}

void *startWatchdog(void*) {

	FILE *fp;
	char path[1035];
	const char *watchdogApp = "Watchdog";
	char client_message[2000];
	int read_size;

	bool bFound = false;
//	printf("yas %d: wd_sock=%d func=%s, file=%s\n",__LINE__,wd_sock,__FUNCTION__,__FILE__);

	fp = popen("/bin/ps | grep Watchdog", "r");
	if (fp == NULL) {
		printf("Failed to run command\n");
	}

	/* Read the output a line at a time - output it. */
	while (fgets(path, sizeof(path) - 1, fp) != NULL) {
		if (strstr(path, watchdogApp) != NULL
				&& strstr(path, "grep Watchdog ") == NULL) {
			bFound = true;
			break;
		}
	}
	/* close */
	pclose(fp);

	if (bFound == false) {
		printf("\n\rStarting Watchdog..\n\r");
		system("Watchdog &");
	}




	while(1){

		//Create socket

		wd_sock = socket(AF_INET , SOCK_STREAM , 0);

		if (wd_sock == -1)

		{

			printf("Could not create socket");

		}

		puts("Socket created");



		server.sin_addr.s_addr = inet_addr("127.0.0.1");

		server.sin_family = AF_INET;

		server.sin_port = htons( 8635 );


		int optval = 1 ;

		if (setsockopt(wd_sock,SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int)) == -1) {

			perror("[Error] Socket configration Error") ;
			//	exit(-1) ;
		}
		printf("yas %d: wd_sock=%d func=%s, file=%s\n",__LINE__,wd_sock,__FUNCTION__,__FILE__);

		while(connect(wd_sock , (struct sockaddr *)&server , sizeof(server)) < 0)
		{
			//perror("connect failed. Error");
		}



		puts("Connected\n");

//		printf("yas %d: wd_sock=%d func=%s, file=%s\n",__LINE__,wd_sock,__FUNCTION__,__FILE__);

		while( (read_size = recv(wd_sock , client_message , 2000 , 0)) > 0 )

		{

			printf("Received: %s\n", client_message);
			if(strncmp("getpid",client_message,strlen("getpid"))==0){
				memset(client_message,0,sizeof(client_message));
				sprintf(client_message,"getpid=%d",cpid);
				write(wd_sock, client_message, strlen(client_message));
			}

		}



		if(read_size == 0)

		{

			puts("Server disconnected");

			fflush(stdout);

		}

		else if(read_size == -1)

		{

			perror("Server recv failed");

		}

		close(wd_sock);
		wd_sock=0;
	}


}

void *Timer(void*)
{

	try {
		int timeout = 0;
		int timeout_limit=0;
		int well_timeout=0;
		int well_timeout_limit=0;
		bool connected;

		while(1){
			connected=serverController.isConnected();
			//if not connected, try to connect to server
			if (connected==true) {
				if(timeout_info[0].timeout_status==true){
					if(timeout_info[0].timeout_cycle==true)
						timeout=0;
					else{
						timeout++;
						timeout_limit++;
					}

					if(timeout>30){
						timeout=0;
						utility.printBytes(timeout_info[0].timeout_packet,0,timeout_info[0].timeout_len);
						if(timeout_info[0].timeout_len>0)
							serverController.sendCommandReply(timeout_info[0].timeout_packet,timeout_info[0].timeout_len);
					}

					if(timeout_limit>300)
						timeout_info[0].timeout_status=false;

					timeout_info[0].timeout_cycle=false;
				}
				//send welcome message, the server will either return success
				//or will return with the values to be written to the registers
				
				
				/*if(timeout_info[1].timeout_status==true){
					if(timeout_info[1].timeout_cycle==true)
						well_timeout=0;
					else{
						well_timeout++;
						well_timeout_limit++;
					}

					if(well_timeout>5){
						well_timeout=0;
						utility.printBytes(timeout_info[1].timeout_packet,0,timeout_info[1].timeout_len);
						if(timeout_info[1].timeout_len>0)
							serverController.socketWrite(timeout_info[1].timeout_packet,timeout_info[1].timeout_len);
							//serverController.sendCommandReply(timeout_info[0].timeout_packet,timeout_info[0].timeout_len);
					}

					if(well_timeout_limit>15)
						timeout_info[1].timeout_status=false;

					timeout_info[1].timeout_cycle=false;
				}*/
				//send welcome message, the server will either return success
				//or will return with the values to be written to the registers
			}

			
			sleep(1);
		}
	} catch (exception &e) {
		cout << "Standard exception: " << e.what() << endl;
	} catch (...) {

	}


	//	pthread_exit(NULL);
}
int main(int argc, char **argv) {

	pthread_t timer_thread, wd,rec_thread;
	cout << endl;
	cout << endl;
	cout << "****************************************" << endl;
	cout << "Moxa Client Application " << endl;
	cout << "Version 1.0.3 " << endl;
	cout << "****************************************" << endl;
	cout << endl;

	cout << "Moxa client starting....." << endl;

	//Wait for a while to ensure the connections are up before start working
#if DEVICE == 1
#endif

#if 1
	
	cpid=getpid();
	printf("yas %d: cpid=%d func=%s, file=%s\n",__LINE__,cpid,__FUNCTION__,__FILE__);
	//pthread_create(&wd, NULL, startWatchdog, NULL);
	//startWatchdog();
#endif

	//signal(SIGPIPE, SIG_IGN);
	memset(dev_config,0,sizeof(struct s_dev_config)*8);
	utility.loadConfiguration();
	utility.loadDevices(dev_config);

	 mkdir("/home/Moxa/remote_cache/", 0755);
	mac_address = utility.getMACAddress();

	if (mac_address[0] == 0 && mac_address[1] == 0) {
		cout << "NO MAC ADDRESS FOUND.. EXITING " << endl;
		return -1;
	}

	total_devices_count = utility.getDevicesCount();

	serverAddress = utility.getServerAddress();
	serverPort = utility.getServerPort();

	cout << endl;
	cout << "Server Address =  " << serverAddress << endl;
	cout << "Server Port    =  " << serverPort << endl;

	printf("MAC Address    =  %02X:%02X:%02X:%02X:%02X:%02X\n", mac_address[0],
			mac_address[1], mac_address[2], mac_address[3], mac_address[4],
			mac_address[5]);

	cout << "Local Devices  =  " << utility.getDevicesIDs() << endl;


	memset(timeout_info,0,sizeof(timeout_info[10]));
	pthread_create(&timer_thread, NULL, Timer, NULL);
	pthread_create(&rec_thread, NULL, Recevier, NULL);

	do {
		if (work() == 0) {
			break;
		}
		cout << endl << " " << endl;
	} while (true);

	cout << endl << " Done..";

	return 0;
}

/*
 * //		int length = 31;
//		unsigned char status_data [] = {0x00, 0x1D, 0x02, 0x1F, 0x03, 0x00, 0xCB, 0x09, 0x2F,
//				0x00, 0xDD, 0x00, 0x00, 0x03, 0xEB, 0x00, 0x00, 0x1E, 0x03, 0x00, 0xCB, 0x09, 0x2A,
//				0x00, 0xDD, 0x00, 0x10, 0x03, 0xEB, 0x00, 0x01};
 *
 * */
