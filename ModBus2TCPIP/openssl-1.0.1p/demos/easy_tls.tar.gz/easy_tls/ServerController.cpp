/*
 * ServerController.cpp
 *
 *  Created on: Feb 14, 2015
 *      Author: imtiazahmed
 */

#include "ServerController.h"
#include <sstream>
#include <iostream>
#include <string.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>     /* strtoul */
#include <errno.h>
#include <iostream>
#include <ctime>

#include "ModbusController.h"

using namespace std;

void ServerController::ShowCerts(SSL* ssl)
{   X509 *cert;
	char *line;

	cert = SSL_get_peer_certificate(ssl);       /* get the server's certificate */
	if ( cert != NULL )
	{
		printf("Server certificates:\n");
		line = X509_NAME_oneline(X509_get_subject_name(cert), 0, 0);
		printf("Subject: %s\n", line);
		free(line);                                                     /* free the malloc'ed string */
		line = X509_NAME_oneline(X509_get_issuer_name(cert), 0, 0);
		printf("Issuer: %s\n", line);
		free(line);                                                     /* free the malloc'ed string */
		X509_free(cert);                                        /* free the malloc'ed certificate copy */
	}
	else
		printf("No certificates.\n");
}

void ServerController::LoadCertificates(SSL_CTX* ctx, char* CertFile, char* KeyFile)
{
	/* set the local certificate from CertFile */
	if ( SSL_CTX_use_certificate_file(ctx, CertFile, SSL_FILETYPE_PEM) <= 0 )
	{
		ERR_print_errors_fp(stderr);
		abort();
	}
	/* set the private key from KeyFile (may be the same as CertFile) */
	if ( SSL_CTX_use_PrivateKey_file(ctx, KeyFile, SSL_FILETYPE_PEM) <= 0 )
	{
		ERR_print_errors_fp(stderr);
		abort();
	}
	/* verify private key */
	if ( !SSL_CTX_check_private_key(ctx) )
	{
		fprintf(stderr, "Private key does not match the public certificate\n");
		abort();
	}
}
ServerController::ServerController() {
	m_server_ip = "";
	m_socket_file_descriptor = 0;

	s_sock_status=1;

	int i;

	for (i = 0; i < MAX_MESSAGE_LENGTH; i++) {
		m_communication_message[i] = 0;
	}

	for (i = 0; i < m_buffer_length; i++) {
		m_buffer[i] = 0;
	}
	if (pthread_mutex_init(&cs_mutex, NULL) != 0)
    {
        printf("\n mutex init failed\n");
       
    }
	certbio = NULL;
	outbio = NULL;
	cert = NULL;
	certname = NULL;
	const SSL_METHOD *method;
	//SSL_CTX *ctx;
	//SSL *ssl;
	//SSL_free(ssl);
	
	//X509_free(cert);
	//SSL_CTX_free(ctx);
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
		OpenSSL_add_all_algorithms();
	ERR_load_BIO_strings();
	ERR_load_crypto_strings();
	SSL_load_error_strings();
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
	/* ---------------------------------------------------------- *
	 * Create the Input/Output BIO's.                             *
	 * ---------------------------------------------------------- */
	certbio = BIO_new(BIO_s_file());
	outbio  = BIO_new_fp(stdout, BIO_NOCLOSE);

	/* ---------------------------------------------------------- *
	 * initialize SSL library and register algorithms             *
	 * ---------------------------------------------------------- */
	if(SSL_library_init() < 0)
		BIO_printf(outbio, "Could not initialize the OpenSSL library !\n");

	/* ---------------------------------------------------------- *
	 * Set SSLv2 client hello, also announce SSLv3 and TLSv1      *
	 * ---------------------------------------------------------- */
	method = SSLv23_client_method();
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
	/* ---------------------------------------------------------- *
	 * Try to create a new SSL context                            *
	 * ---------------------------------------------------------- */
	if ( (ctx = SSL_CTX_new(method)) == NULL)
		BIO_printf(outbio, "Unable to create a new SSL context structure.\n");

	/* ---------------------------------------------------------- *
	 * Disabling SSLv2 will leave v3 and TSLv1 for negotiation    *
	 * ---------------------------------------------------------- */
	SSL_CTX_set_options(ctx, SSL_OP_NO_SSLv2);

	LoadCertificates(ctx, "ca1-cert.pem", "ca1-key.pem"); 


	//using a store from examples
	if(! SSL_CTX_load_verify_locations(ctx, "root-cert.pem", NULL))
	{
		/* Handle failed load here */
		printf( "Faild load verify locations\n");

	}
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
	/* ---------------------------------------------------------- *
	 * Create new SSL connection state object                     *
	 * ---------------------------------------------------------- */
	ssl = SSL_new(ctx);

}

ServerController::~ServerController() {
}

bool ServerController::connectWithServer(string server_ip, int server_port,int& wd_socket) {
	
	int code;
	int connect_tries=0;

	s_sock_status=1;
	m_port = server_port;
	m_server_ip = server_ip; //server_ip;
	m_server = gethostbyname(m_server_ip.c_str()); //server_ip
	if(m_socket_file_descriptor)
		close(m_socket_file_descriptor);
	m_socket_file_descriptor = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

#if DEBUG  == 1
	cout << "Server = " << server_ip << " Port = " << server_port << endl;
#endif

	if (m_socket_file_descriptor < 0) {
		cout << ("ERROR opening socket\n") << endl;
		return false;
	}

	if (m_server == NULL) {
		cout << "ERROR, no such host" << endl;
		return false;
	}

	bzero((char *) &m_serv_addr, sizeof(m_serv_addr));

	m_serv_addr.sin_family = AF_INET;

	bcopy((char *) m_server->h_addr, (char *)&m_serv_addr.sin_addr.s_addr, m_server->h_length);

	m_serv_addr.sin_port = htons(m_port);

	do{
		code = connect(m_socket_file_descriptor,
				(struct sockaddr *) &m_serv_addr, sizeof(m_serv_addr));

		if (code < 0) {
			//cout << "Connect failed. Error " << endl;
			printf("Connect failed %d:   %s log_timeout_count=%d\n",errno, strerror(errno),connect_tries);
			sleep(1);
			//			printf("yas %d: wd_socket=%d func=%s, file=%s\n",__LINE__,wd_socket,__FUNCTION__,__FILE__);
			if(wd_socket>0)
				write(wd_socket, "ping", strlen("ping"));
			connect_tries++;
			if(connect_tries>900/*300*/){
				connect_tries=0;
				return false;
			}
			//	return false;
		} 
	}while(code<0);
	//sleep(10);
#if 1
	timeout.tv_sec = 30;
	timeout.tv_usec = 0;

	if (setsockopt (m_socket_file_descriptor, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout,
				sizeof(timeout)) < 0){
		printf("setsockopt failed\n");
		return false;
	} else {
#if DEBUG  == 1
		cout << "Connected with server!" << endl;
#endif
		//		return true;
	}

	if (setsockopt (m_socket_file_descriptor, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout,
				sizeof(timeout)) < 0){
		printf("setsockopt failed\n");
		return false;
	}
#endif

	int a = 65535;
	if (setsockopt(m_socket_file_descriptor, SOL_SOCKET, SO_RCVBUF, &a, sizeof(int)) == -1) {
		fprintf(stderr, "Error setting socket opts: %s\n", strerror(errno));
	}

	//s_sock_status=0;
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
	
	
	
#if 1	
	///////////////////////////////ssl///////////////////////////////////////////////////
	SSL_set_fd(ssl, m_socket_file_descriptor);
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
	/* ---------------------------------------------------------- *
	 * Try to SSL-connect here, returns 1 for success             *
	 * ---------------------------------------------------------- */
	 //SSL_connect(ssl) ;
	if ( SSL_connect(ssl) != 1 )
		BIO_printf(outbio, "Error: Could not build a SSL session .\n");
	else
		BIO_printf(outbio, "Successfully enabled SSL/TLS session \n");

	/* ---------------------------------------------------------- *
	 * Get the remote certificate into the X509 structure         *
	 * ---------------------------------------------------------- */
#if 0	 
	cert = SSL_get_peer_certificate(ssl);
	if (cert == NULL)
		BIO_printf(outbio, "Error: Could not get a certificate from: .\n");
	else
		BIO_printf(outbio, "Retrieved the server's certificate from: \n");

	ShowCerts(ssl);
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);

	if(SSL_get_verify_result(ssl) != X509_V_OK)
	{
		/* Handle the failed verification */
		printf("Failed get verify result \n");
		printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
		fprintf(stderr, "Certificate verification error: %i\n", SSL_get_verify_result(ssl));
		//do not exit here (but some more verification would not hurt) because if you are using a self-signed certificate you will receive 18
		//18 X509_V_ERR_DEPTH_ZERO_SELF_SIGNED_CERT which is not an error
	}

	/* ---------------------------------------------------------- *
	 * extract various certificate information                    *
	 * -----------------------------------------------------------*/
	certname = X509_NAME_new();
	//certname = X509_get_subject_name(cert);
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);

	/* ---------------------------------------------------------- *
	 * display the cert subject here                              *
	 * -----------------------------------------------------------*/
	BIO_printf(outbio, "Displaying the certificate subject data:\n");
	X509_NAME_print_ex(outbio, certname, 0, 0);
	BIO_printf(outbio, "\n");
#endif	
#endif	
	///////////////////////////////end ssl/////////////////////////////////////////////////
	s_sock_status=0;
	return true;

}

int ServerController::disconnect() {

	s_sock_status=1;
	if (m_socket_file_descriptor > 0) {
#if DEBUG  == 1
		//cout << "Disconnected successfully" << endl;
#endif
		return close(m_socket_file_descriptor);

	} else {
		cout << "Socket was not connected" << endl;
		return -1;
	}

}

void ServerController::setIDForCommunication(unsigned char* mac_address) {

	//copy 6 bytes of mac address at the beginning of the message
	for (int i = 0; i < 6; i++) {
		m_communication_message[i] = mac_address[i];
	}

}

/**
 * Send welcome command
 */
void ServerController::sendWelcomeMessage(struct s_timeout_info* timeout_info) {

	clearMessage();
	
	m_communication_message[COMMAND_INDEX] = CONNECT_MESSAGE_COMMAND;
	setcurrentver();
	updateCommandLength(3);

	//for this command the read and write length is same (9)
	int bytesToWrite = MESSAGE_LENGTH_INDEX + 2 + 3;
	timeout_info[1].timeout_status=true;
	timeout_info[1].timeout_cycle=false;
	timeout_info[1].timeout_len=bytesToWrite;

	memcpy(timeout_info[1].timeout_packet,m_communication_message,bytesToWrite);
	sendPreparedBytesToServer(bytesToWrite, bytesToWrite);

}
ssize_t ServerController::socketWrite(void *sock_buf, size_t sock_count){
	int ret=0;
	pthread_mutex_lock( &cs_mutex );
	//printf("yas %d: ret=%d errno=%d func=%s, file=%s\n",__LINE__,ret,errno,__FUNCTION__,__FILE__);
	if(s_sock_status==0)
		ret=SSL_write(ssl, sock_buf,sock_count);
	pthread_mutex_unlock( &cs_mutex );
	//printf("yas %d: ret=%d errno=%d func=%s, file=%s\n",__LINE__,ret,errno,__FUNCTION__,__FILE__);
		/* If we've got data to write then try to write it*/              
	if(ret<0)	
		printf("yas %d: ret=%d errno=%d func=%s, file=%s\n",__LINE__,ret,errno,__FUNCTION__,__FILE__);
		//ret=write(m_socket_file_descriptor, sock_buf,sock_count);
	return ret;
}
ssize_t ServerController::socketRead(void *sock_buf, size_t sock_count){

	//	return read(sock_fd,sock_buf,sock_count);

	//return recv(m_socket_file_descriptor , sock_buf , sock_count , 0);
#if DEBUG == 1
			printBytes(true, m_length);
			cout << "Total bytes written on socket" << m_length << endl;
#endif
			
			if(m_socket_file_descriptor<1)
				return 0;
			
			struct timeval tval;
			fd_set rset, wset;
			
			FD_ZERO(&rset);
    FD_ZERO(&wset);
    FD_SET(m_socket_file_descriptor, &rset);
    FD_SET(m_socket_file_descriptor, &wset);
    int error;
    socklen_t len;
    tval.tv_sec = 0;
    tval.tv_usec = 6;
    int ret=select(m_socket_file_descriptor+1, &rset, &wset, NULL,&tval);
    if ( ret == 0) {
//        return -1;
    }
    /*if(FD_ISSET(m_socket_file_descriptor,&rset) || FD_ISSET(m_socket_file_descriptor, &wset )) {
        len = sizeof(error);
        if(getsockopt(m_socket_file_descriptor, SOL_SOCKET, SO_ERROR, &error, &len) < 0){
  //          return -1;
        }
    }else{
        printf("m_socket_file_descriptor  not set\n");
    //    return -1;
    }*/
			
			//pthread_mutex_lock( &cs_mutex );
		//	printf("yas %d: m_reading_length=%d errno=%d func=%s, file=%s\n",__LINE__,m_reading_length,errno,__FUNCTION__,__FILE__);
			//Bytes written on socket, now going to read the server reply
			//m_reading_length = recv(m_socket_file_descriptor , sock_buf , MAX_MESSAGE_LENGTH , 0);
			m_reading_length=SSL_read(ssl, sock_buf, MAX_MESSAGE_LENGTH);  
			//pthread_mutex_unlock( &cs_mutex );
		//	printf("yas %d: m_reading_length=d errno=%d func=%s, file=%s\n",__LINE__,m_reading_length,errno,__FUNCTION__,__FILE__);

			if(m_reading_length == 0 || errno==11)
			{
				printf("yas %d: m_reading_length=d errno=%d func=%s, file=%s\n",__LINE__,m_reading_length,errno,__FUNCTION__,__FILE__);
				s_sock_status=1;
				close(m_socket_file_descriptor);
				puts("Client disconnected");
			}
			else if(m_reading_length == -1)
			{
				s_sock_status=1;
				close(m_socket_file_descriptor);
				fprintf(stdout,"[Error] Socket read failed%d:	%s",errno, strerror(errno));
			}
			else {

#if DEBUG == 1

				printBytes(false, m_reading_length);
				cout << "Total bytes read from Server" << m_reading_length << endl;
#endif
			}
			return m_reading_length;
}

/**
 * Send prepared m_communication_message to server.
 * Before calling this method, the data in m_communication_message needs to be prepared first.
 *
 * write_length indicates the number of bytes to send from m_communication_message
 * read_length indicates the number of bytes to read from incoming reply
 */
int ServerController::sendPreparedBytesToServer(unsigned int write_length,
		unsigned int read_length) {

	try {

		m_length = socketWrite(m_communication_message,write_length);

		if (m_length < 0) {
			//printf("yas %d: m_length=d errno=%d func=%s, file=%s\n",__LINE__,m_length,errno,__FUNCTION__,__FILE__);
			cout << "ERROR writing to socket" << endl;
			m_length = 0;
			s_sock_status=1;
			close(m_socket_file_descriptor);

		} else {
#if 0
#if DEBUG == 1
			printBytes(true, m_length);
			cout << "Total bytes written on socket" << m_length << endl;
#endif
			//Bytes written on socket, now going to read the server reply
			m_reading_length = read(m_socket_file_descriptor, m_buffer,
					MAX_MESSAGE_LENGTH);

			if(m_reading_length == 0 || errno==11)
			{
				s_sock_status=1;
				close(m_socket_file_descriptor);
				puts("Client disconnected");
			}
			else if(m_reading_length == -1)
			{
				s_sock_status=1;
				close(m_socket_file_descriptor);
				fprintf(stdout,"[Error] Socket read failed%d:	%s",errno, strerror(errno));
			}
			else {

#if DEBUG == 1

				printBytes(false, m_reading_length);
				cout << "Total bytes read from Server" << m_reading_length << endl;
#endif
			}
#endif
		}

	} catch (...) {
		m_length = 0;
	}

	return m_length;

}

unsigned long ServerController::getLongFromByte(unsigned char* array,
		int start_position) {

	return ((array[start_position + 3] << 24)
			| (array[start_position + 2] << 16)
			| (array[start_position + 1] << 8) | (array[start_position]));

}

bool ServerController::logDevicesStatus(unsigned char* data, int length) {

        //clearMessage();
        int bytesToWrite;
        int byteToRead;

		memset(m_communication_message,6,6);
        
        //clearMessage();
	if(length>0){
		m_communication_message[COMMAND_INDEX] = GET_STATUS_OF_ALL_SLAVES_COMMAND;
		updateCommandLength(length);

		//for this command write length comes as a parameter
		bytesToWrite = MESSAGE_LENGTH_INDEX + 1 + length;
		byteToRead = 9;

		for (int i = 0; i < MAX_MODBUS_MESSAGE_LENGTH; i++) {
			m_communication_message[MESSAGE_LENGTH_INDEX + i] = data[i];
		}
	}
	else{
		m_communication_message[COMMAND_INDEX] = REPORT_SLAVE_STATUS_COMMAND;
		updateCommandLength(4);

		//for this command write length comes as a parameter
		bytesToWrite = MESSAGE_LENGTH_INDEX + 1 + 6;
		byteToRead = 9;
		m_communication_message[10]=1;
		m_communication_message[11]=data[3];

		/*                for (int i = 0; i < 4; i++) {
				  m_communication_message[10 + i] = data[i];
				  }*/
	}
	
	printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
        printBytes(true,bytesToWrite);
        printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
	logDeviceStatus(m_communication_message, bytesToWrite);	
//        return sendPreparedBytesToServer(bytesToWrite, byteToRead) > 0;
}
bool ServerController::sendDevicesStatus(unsigned char* data, int length) {

	//clearMessage();
	int bytesToWrite;
	int byteToRead;

	if(length>0){
		m_communication_message[COMMAND_INDEX] = GET_STATUS_OF_ALL_SLAVES_COMMAND;
		updateCommandLength(length);

		//for this command write length comes as a parameter
		bytesToWrite = MESSAGE_LENGTH_INDEX + 1 + length;
		byteToRead = 9;

		for (int i = 0; i < MAX_MODBUS_MESSAGE_LENGTH; i++) {
			m_communication_message[MESSAGE_LENGTH_INDEX + i] = data[i];
		}
	}
	else{
		m_communication_message[COMMAND_INDEX] = REPORT_SLAVE_STATUS_COMMAND;
		updateCommandLength(4);

		//for this command write length comes as a parameter
		bytesToWrite = MESSAGE_LENGTH_INDEX + 1 + 6;
		byteToRead = 9;
		m_communication_message[10]=1;
		m_communication_message[11]=data[3];

		/*                for (int i = 0; i < 4; i++) {
				  m_communication_message[10 + i] = data[i];
				  }*/
	}

	return sendPreparedBytesToServer(bytesToWrite, byteToRead) > 0;

}

void ServerController::clearMessage() {

	for (int i = COMMAND_STATUS_INDEX; i < MAX_MESSAGE_LENGTH; i++) {
		m_communication_message[i] = 0;
	}

}

bool ServerController::isConnected(){
	if(s_sock_status==0)
		return true;
	else
		return false;

}

void ServerController::setcurrentver() {

	
        char buffer[50];
        long length;
        FILE * f = fopen ("/home/Moxa/version", "rb");
	memset(buffer,0,50);

        if (f)
        {
                fseek (f, 0, SEEK_END);
                length = ftell (f);
                fseek (f, 0, SEEK_SET);
                fread (buffer, 1, length, f);
                fclose (f);
        }

        if (strlen(buffer)>0)
        {
                // start to process your data / extract strings here...
		int index=0,len=0;
		char num[10];
		//index=m_utility.findpattren(buffer, '.', length,1,0);	
		while(buffer[index]!='.' && index < length )
			index++;
		strncpy(num,buffer,index);
		m_communication_message[10]=atoi(num);

		index++;
		len=index;

		//index=m_utility.findpattren(buffer, '.', length,1,index);
		while(buffer[index]!='.' && index < length )
			index++;
                strncpy(num,buffer+len,index-len);
                m_communication_message[11]=atoi(num);


		index++;
		len=index;

		//index=m_utility.findpattren(buffer, '.', length,1,index);
		while(buffer[index]!='.' && index < length )
                       index++;
                strncpy(num,buffer+len,index-len);
                m_communication_message[12]=atoi(num);
		
        }
        else{

		m_communication_message[10]=0;
		m_communication_message[11]=0;
		m_communication_message[12]=0;

        }


}
void ServerController::updateCommandLength(int length) {

	//Set the status to 2 to indicate that this message is request.
	m_communication_message[COMMAND_STATUS_INDEX] = 2;

	for (int i = MESSAGE_LENGTH_INDEX; i < MESSAGE_LENGTH_INDEX + 2; i++)
		m_communication_message[i] = (length >> (i * 8));

}

void ServerController::getArrayFromLong(unsigned long number,
		unsigned char* array, int start_position) {

	for (int i = start_position; i < 4; i++)
		array[i] = (number >> (i * 8));

}

unsigned char* ServerController::getLastReplyFromServer(int& length_of_data) {

	length_of_data = m_reading_length;
	return m_buffer;

}

void ServerController::printBytes(bool out_going, int length) {

//#if DEBUG == 1
	cout << endl << "Printing bytes = ";
	int i;

	for (i = 0; i < length; i++) {
		if (i > 0) {
			printf(":");
		}
		if(out_going)
		{
			printf("%02X", m_communication_message[i]);
		}
		else
		{
			printf("%02X", m_buffer[i]);
		}
	}
	cout << endl;
//#endif

}

void ServerController::sendCommandReply(unsigned char* packets,int length) {

/*        printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);
        printBytes(packets,length);
        printf("yas %d: func=%s, file=%s\n",__LINE__,__FUNCTION__,__FILE__);*/
	int n=socketWrite(packets,length);
	if (n < 0){ 
		printf("ERROR writing to socket");
		s_sock_status=1;
		close(m_socket_file_descriptor);
	}

	//TODO implement the code to reply back the result of writing
	//to registers
}
int ServerController::insertRecord(FILE * f, unsigned char* data, int length){
	time_t now = time(0);
	fprintf(f, "%ld:",now);
            //Some calculations to fill a[]
        fwrite(data, 1, length, f);
        fprintf(f, ";");
    
	
}

int ServerController::logDeviceStatus (unsigned char* data, int length)
{
	
	FILE * cashe;
	FILE * cashe_temp;
	char cached[]={"/home/Moxa/data_cashe"};
	char cached_temp[]={"/home/Moxa/data_cashe_temp"};
	int lines=0;
	char ch;

	cashe = fopen (cached,"rb");
	if (cashe == NULL)
	{

		cashe = fopen (cached,"wb");
		if (cashe == NULL)
			printf("Error opening file! data_cashe \n");

		//fprintf(cashe,"%ld:%s;",now,data);
		insertRecord(cashe,data,length);
		fclose(cashe);
		return 0;

	}

	while(!feof(cashe))
	{
		ch = fgetc(cashe);
		if(ch == ';')
		{
			lines++;
			printf("yas %d: current line num=%d func=%s, file=%s\n",__LINE__,lines,__FUNCTION__,__FILE__);
		}
	}
	printf("Number of lines=%d\n",lines);
	if(lines>95){

		cashe_temp = fopen (cached_temp,"wb");
		if (cashe_temp == NULL)
		{
			printf("Error opening file! data_cashe_temp\n");

		}
		rewind(cashe);
		do{
			ch = fgetc(cashe);
		}while((ch != ';'));
		
		while(!feof(cashe)){
			ch = fgetc(cashe);

			putc(ch, cashe_temp);
		}

		//fprintf(cashe_temp,  "%ld:%s;",now,data);
		insertRecord(cashe_temp,data,length);

		fclose(cashe_temp);
		fclose(cashe);
		if(remove(cached) == 0)
			printf("File %s  deleted.\n", cached);
		else
			fprintf(stderr, "Error deleting the file %s.\n", cached);

		if(rename(cached_temp, cached) == 0)
		{
			printf("%s has been rename %s.\n", cached_temp, cached);
		}
		else
		{
			fprintf(stderr, "Error renaming %s.\n", cached_temp);
		}
		return 0;
	}
	else{
		fclose(cashe);
		cashe = fopen (cached,"ab");
		if (cashe == NULL){
			cashe = fopen (cached,"wb");
			if (cashe == NULL)
				printf("Error opening file! data_cashe \n");
		}
		//fprintf(cashe,  "%ld:%s\n",now,data);
		insertRecord(cashe,data,length);
		fclose(cashe);

	}

	return 0;
}
